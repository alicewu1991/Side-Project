import React from 'react';

const HomepageBtn=()=>{
    return (
        <div className="w-10 h-10 bg-primary text-white font-bold ">
            <p>TM</p>
        </div>
    );
}
export default HomepageBtn;