import React from 'react';


const ReleaseBtn =()=>{
    return (
        
        <button className="w-44 h-14 rounded-xl  text-secondary_light font-bold">
        <h3>Release on 5/27</h3>
        </button>
    )
}

export default ReleaseBtn;