import React from 'react';


const Footer=()=>{
    return(
        <div className=" w-full  flex flex-row justify-center items-center text-secondary_light text-base">
            <p className="font-bold">Typemaster 2021 |  </p>
            <p> All Rights Reserved</p>
        </div>
    )
}

export default Footer;